create view version as
select '2.1.0' AS `sys_version`, version() AS `mysql_version`;

